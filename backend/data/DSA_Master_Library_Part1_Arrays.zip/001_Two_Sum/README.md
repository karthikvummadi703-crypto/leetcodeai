# 001_Two_Sum

Original interview-style description:
Find two indices whose values sum to target.

## Intuition
Explain the core idea here.

## Approaches
- Brute
- Better
- Optimal
