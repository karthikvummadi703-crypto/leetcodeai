# 005_Best_Time_Stock

Original interview-style description:
Maximum profit from one transaction.

## Intuition
Explain the core idea here.

## Approaches
- Brute
- Better
- Optimal
