class Solution {
    // TODO
}
