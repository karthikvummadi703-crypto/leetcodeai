# 003_Longest_Common_Prefix

Find longest common prefix.

## Intuition
TODO
