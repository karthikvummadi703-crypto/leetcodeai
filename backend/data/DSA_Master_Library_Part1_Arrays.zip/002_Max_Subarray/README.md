# 002_Max_Subarray

Original interview-style description:
Find the maximum sum contiguous subarray.

## Intuition
Explain the core idea here.

## Approaches
- Brute
- Better
- Optimal
