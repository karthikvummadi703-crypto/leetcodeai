# 004_Move_Zeroes

Original interview-style description:
Move all zeroes to the end.

## Intuition
Explain the core idea here.

## Approaches
- Brute
- Better
- Optimal
