# 003_Remove_Duplicates_Sorted

Original interview-style description:
Remove duplicates in-place from sorted array.

## Intuition
Explain the core idea here.

## Approaches
- Brute
- Better
- Optimal
